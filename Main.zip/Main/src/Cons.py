"""
Constants, defines:
* Data train and test file path.
* Image height \ width to resize when loading data.
* Deep learning models constants, such as epochs, train percent, batch sizes.

"""

PATH = "src\\"
MODELS_PATH = PATH + 'models\\'
IMG_H = 64
IMG_W = IMG_H
CHANNELS = 3
LABELS = [0, 6, 8] ## 6, 8 - Coins with six or eight rays, respectively. 0 - Undefined, non 6 or 8, non-ancient or damaged.

import keras
import tensorflow as tf
import os
import math
import random
import numpy as np
import PIL
