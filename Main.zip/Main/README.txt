Navigate to this folder via command line
Type in command line
"python run.py"

This should install the required libaries and run the user interface.