import subprocess

if __name__ == '__main__':
    print("\n\nThis will instal the following libraries:")
    print("--- Model loading and prediction ---")
    print("keras")
    print("tensorflow")
    print("--- User interface ---")
    print("customtkinter")
    print("tkinterdnd2")
    print("pillow")
    
    print("\n\nDo you wish to continue? Y \ n");
    user_input = input()
    if 'y' in user_input.lower():
        
        subprocess.run(['pip', 'install', '--upgrade', 'pip'])
        for lib in ['tensorflow>=2.13.0', 'keras>=2.13.1', 'customtkinter>=5.1.3', 'tkinterdnd2>=0.3.0', 'pillow>=8.4.0']:
            try:
                subprocess.run(['pip', 'install', lib])
            except e:
                print(f'Could not install {lib}')
         
        result = subprocess.run(["python", "src\\Gui.py"])